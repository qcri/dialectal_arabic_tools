import codecs
import subprocess
from collections import Counter
from itertools import chain

import numpy as np
#import theano
np.random.seed(1337)  # for reproducibility
from keras.preprocessing import sequence
from keras.layers import Dense, Embedding, ChainCRF, LSTM, Bidirectional, Dropout
from keras.layers.wrappers import TimeDistributed
from keras.optimizers import RMSprop
from keras.callbacks import EarlyStopping, ModelCheckpoint
from keras.models import Sequential


def getLabels(filepath):
    labels = []
    for line in codecs.open(filepath, 'r','utf-8'):
        line = line.strip()
        if len(line) == 0:
            continue
        splits = line.split('\t')
        labels.append(splits[1].strip())
    return list(set(labels))


POS_TAGS = ['S','WB','M','E','B']
print POS_TAGS,'\n'
label2Idx = dict((l, i) for i, l in enumerate(POS_TAGS))
idx2Label = dict((i, l) for i, l in enumerate(POS_TAGS))


def load_data():
    X_words_train, y_train = load_file('train.txt')
    X_words_dev, y_dev = load_file('dev.txt')
    X_words_test, y_test = load_file('test.txt')

    index2word = _fit_term_index(X_words_train, reserved=['<PAD>', '<UNK>'])
    word2index = _invert_index(index2word)

    index2pos = POS_TAGS
    pos2index = _invert_index(index2pos)

    X_words_train = np.array([[word2index[w] for w in words] for words in X_words_train])
    y_train = np.array([[pos2index[t] for t in pos_tags] for pos_tags in y_train])

    X_words_dev = np.array([[word2index.get(w, word2index['<UNK>']) for w in words] for words in X_words_dev])
    y_dev = np.array([[pos2index[t] for t in pos_tags] for pos_tags in y_dev])

    X_words_test = np.array([[word2index.get(w, word2index['<UNK>']) for w in words] for words in X_words_test])
    y_test = np.array([[pos2index[t] for t in pos_tags] for pos_tags in y_test])

    return (X_words_train, y_train),(X_words_dev, y_dev), (X_words_test, y_test), (index2word, index2pos)


def _fit_term_index(terms, reserved=[], preprocess=lambda x: x):
    all_terms = chain(*terms)
    all_terms = map(preprocess, all_terms)
    term_freqs = Counter(all_terms).most_common()
    id2term = reserved + [term for term, tf in term_freqs]
    return id2term


def _invert_index(id2term):
    return {term: i for i, term in enumerate(id2term)}


def load_file(path):
    """
    Load sentences. A line must contain at least a word and its tag.
    Sentences are separated by empty lines.
    """
    sentences = []
    sentence = []
    for line in codecs.open(path,'r','utf-8'):
        line = line.rstrip()
        if not line:
            if len(sentence) > 0:
                if 'DOCSTART' not in sentence[0][0]:
                    sentences.append(sentence)
                sentence = []
        else:
            word = line.split()
            assert len(word) >= 2
            sentence.append(word)
    if len(sentence) > 0:
        if 'DOCSTART' not in sentence[0][0]:
            sentences.append(sentence)
    words, pos_tags = zip(*[zip(*row) for row in sentences])
    return words, pos_tags


word_embedding_dim = 200
lstm_dim = 100
batch_size = 30

print('Loading data...\n')

(X_words_train,y_train), (X_words_dev, y_dev), (X_words_test, y_test), (index2word, index2pos) = load_data()

seq_len = []
for i in range(len(X_words_test)):
    seq_len.append(len(X_words_test[i]))
print max(seq_len)

maxlen = max(seq_len)  # cut texts after this number of words (among top max_features most common words)
print("Number of words: ")
print(len(np.unique(np.hstack(X_words_train))))
print("Sequence length: ")
result = map(len,X_words_train)
print("Mean %.2f words (%f)" % (np.mean(result),np.std(result)))

#pyplot.subplot(121)
#pyplot.boxplot(result)
#pyplot.subplot(122)
#pyplot.hist(result)
#pyplot.show()


max_features = len(index2word)
nb_pos_tags = len(index2pos)

X_words_train = sequence.pad_sequences(X_words_train, maxlen=maxlen, padding='post')
X_words_dev = sequence.pad_sequences(X_words_dev, maxlen=maxlen, padding='post')
X_words_test = sequence.pad_sequences(X_words_test, maxlen=maxlen, padding='post')

y_train = sequence.pad_sequences(y_train, maxlen=maxlen, padding='post')
y_train = np.expand_dims(y_train, -1)

y_dev = sequence.pad_sequences(y_dev, maxlen=maxlen, padding='post')
y_dev = np.expand_dims(y_dev, -1)

y_test = sequence.pad_sequences(y_test, maxlen=maxlen, padding='post')
y_test = np.expand_dims(y_test, -1)


print('Unique words:', max_features)
print('Unique pos_tags:', nb_pos_tags)

print('X_words_train shape:', X_words_train.shape)
print('X_words_test shape:', X_words_dev.shape)
print('X_words_test shape:', X_words_test.shape)

print('y_train shape:', y_train.shape)
print('y_test shape:', y_dev.shape)
print('y_test shape:', y_test.shape)


print('Build model...')

model = Sequential()
model.add(Embedding(max_features, word_embedding_dim, input_length=maxlen, name='word_emb', mask_zero=True))
model.add(Dropout(0.5))
model.add(Bidirectional(LSTM(lstm_dim,return_sequences=True)))
model.add(Dropout(0.5))
model.add(TimeDistributed(Dense(nb_pos_tags)))
crf = ChainCRF()
model.add(crf)
model.summary()
model.compile(loss=crf.sparse_loss,
               optimizer= RMSprop(0.01),
               metrics=['sparse_categorical_accuracy'])

early_stopping = EarlyStopping(patience=10, verbose=1)
checkpointer = ModelCheckpoint("model/seg_keras_weights-3.hdf5",verbose=1,save_best_only=True)

print('Train...')

history = model.fit(X_words_train, y_train,
                     batch_size=batch_size,
                     nb_epoch=200,
                     verbose=1,
                     shuffle=True,
                     callbacks=[early_stopping, checkpointer],
                     validation_data=[X_words_dev, y_dev])

model.load_weights('model/seg_keras_weights-3.hdf5')

from sklearn.metrics import classification_report

test_y_pred = model.predict(X_words_test).argmax(-1)[X_words_test > 0]
test_y_true = y_test[X_words_test > 0]

print('\n---- Result of BiLSTM-CRF ----\n')

print(classification_report(test_y_true, test_y_pred, target_names=POS_TAGS))

test_pred_f = codecs.open("seg_test_out", "wb","utf-8")


in_data = []
for i in range(len(X_words_test)):
    for j in range(len(X_words_test[i])):
        if X_words_test[i][j] > 0:
            in_data.append(index2word[X_words_test[i][j]])

for i in range(len(test_y_pred)):
    test_pred_f.write(in_data[i]+"\t"+idx2Label.get(test_y_true[i][0])+'\t'+idx2Label.get(test_y_pred[i])+"\n")

test_f = "seg_test_out"

subprocess.call(["sh", "-c", "perl bin/char2word.pl "+str(test_f)+" "+str(test_f)+"_words.txt"])
subprocess.call(["sh", "-c", 'perl bin/conlleval.pl -r < '+str(test_f)+'_words.txt -d "\t" > result.txt' ])
subprocess.call(["sh", "-c", 'head -2  < result.txt   '])

# # summarize history for loss
# pyplot.plot(history.history['loss'])
# pyplot.plot(history.history['val_loss'])
# pyplot.title('model loss')
# pyplot.ylabel('loss')
# pyplot.xlabel('epoch')
# pyplot.legend(['train', 'test'], loc='upper right')
# pyplot.show()

